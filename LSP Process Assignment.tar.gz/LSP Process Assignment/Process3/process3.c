#include"header.h"

int main()
{
		printf("Inside Process 3\n");

	return 0;
}

