#include"header.h"

int main()
{

		printf("Inside Process 2\n");

	return 0;
}

