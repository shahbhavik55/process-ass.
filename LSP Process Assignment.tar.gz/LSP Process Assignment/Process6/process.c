#include"header.h"

int main()
{
	printf("Parent : Process running\n");

	if(fork() == 0)
	{
		execl("./FileWriter",NULL,NULL);
	}
	return 0;
}
