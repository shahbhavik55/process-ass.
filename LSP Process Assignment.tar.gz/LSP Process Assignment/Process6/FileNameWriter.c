/*
	Write a program which accept directory name from user and write information of all regular file in and then read the contents from that file.
*/

#include"header.h"

int main() 
{
	DIR *dir;
	struct dirent *entry;
	struct stat filestat;
	char name[100] = {'\0'};
	int fd;

	typedef struct
	{
		char name[50];
		int ino;
		int size;
	}FILEINFO;
	FILEINFO obj;

	// Open the directory
	if ((dir = opendir("/home/manthan/Desktop/")) == NULL)
	{
		printf("Unable to open specified directory\n");
		return -1;
	}

	fd = creat("Info",0666);
	if(fd == -1)
	{
		printf("Unable to create file\n");
		return -1;
	}	

	while ((entry = readdir(dir)) != NULL)
	{
		// Create absolute path
		sprintf(name,"/home/manthan/Desktop/%s",entry->d_name);
		stat(name,&filestat);

		// Check file type			
		if(S_ISREG(filestat.st_mode))
		{
			strcpy(obj.name,entry->d_name);
			obj.ino = filestat.st_ino;
			obj.size = filestat.st_size;

			write(fd,&obj,sizeof(obj));
		}	
	}

	// closedir() close the directory which is opened by opendir()
	closedir(dir);
		
	return 0;
}
