#include"header.h"

int main()
{
	int status;
	pid_t pid;
	
	if(fork() == 0)
	{
		printf("Before process creation\n");
		execl("./executable3","NULL",NULL);
		printf("Execution of child process completed\n");
	}
	
	else
	{
		printf("Inside Parent process\n");
		pid = wait(&status);

		printf("Child process having PID %d terminates with exit status %d\n",pid,status);
		printf("Execution of parent process completed\n");
	}

	return 0;
}
